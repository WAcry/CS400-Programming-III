/**
 * Main.java created by Ziyuan Zhang on Lenovo Yoga 720 in p5 Hello FX
 *
 * Author:    Ziyuan Zhang (zzhang949@wisc.edu)
 * Date:      4/15/2020
 *
 * Course:    CS400
 * Semester:  Spring 2020
 * Lecture:   001
 *
 * IDE:       Intellij IDEA IDE for Java Developers
 * Version:   2019.3.2
 * Build id:  193.6015.39
 *
 * Device:    Ziyuan-Yoga720
 * OS:        Windows 10 Home
 * Version:   1903
 * OS build:  18362.535
 */

package application;

import java.io.FileInputStream;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Main class of the program
 *
 * @author Ziyuan Zhang
 */
public class Main extends Application {

  /**
   * A class to start the program GUI
   * @param primaryStage default Stage object
   * @throws Exception any Exception, like IOException for this program
   */
  @Override
  public void start(Stage primaryStage) throws Exception {
    BorderPane bp = new BorderPane();

    // set label on the top
    Label topLabel = new Label("CS400 My First JavaFX Program");
    bp.setTop(topLabel);
    BorderPane.setAlignment(topLabel, Pos.TOP_CENTER);

    // set the comboBox on the left
    ComboBox<String> leftChoiceBox = new ComboBox<>(
        FXCollections.observableArrayList("A", "B", "C"));
    bp.setLeft(leftChoiceBox);

    // set the image on the center
    FileInputStream input = new FileInputStream("src/image.png");
    Image selfPortrait = new Image(input, 300,400,true,true);
    ImageView centerImageView = new ImageView(selfPortrait);
    bp.setCenter(centerImageView);

    // set the button on the bottom
    Button bottomButton = new Button("Done");
    bp.setBottom(bottomButton);
    BorderPane.setAlignment(bottomButton, Pos.BOTTOM_CENTER);
    bottomButton.setOnAction((ActionEvent e) -> {
      primaryStage.close(); // close the window
    });

    // set elements of the right part of the GUI
    TextField leftTextfield = new TextField();
    leftTextfield.setPromptText("Enter your name here");
    Button leftButton = new Button("ok");
    Label rightResult = new Label();
    leftButton.setOnAction((ActionEvent e) -> {
      // say hi to the user
      if (leftTextfield.getText() != null && !leftTextfield.getText().isEmpty()) {
        rightResult.setText("Hi, " + leftTextfield.getText() + "!");
      } else {
        rightResult.setText(""); // clear the result
      }
    });

    // combine and form the right part
    VBox RightVbox = new VBox();
    RightVbox.setAlignment(Pos.TOP_CENTER);
    RightVbox.getChildren().addAll(leftTextfield, leftButton, rightResult);
    bp.setRight(RightVbox);

    // deal the GUI stage
    primaryStage.setTitle("CS400 My First JavaFX Program");
    primaryStage.setScene(new Scene(bp, 600, 500));
    primaryStage.setResizable(false);
    primaryStage.show();
  }

  /**
   * Main method of the program to launch
   * @param args input arguments
   */
  public static void main(String[] args) {
    launch(args);
  }
}
