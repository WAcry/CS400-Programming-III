package application;

import java.io.FileInputStream;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

  @Override
  public void start(Stage primaryStage) throws Exception {
    // label on the top
    Label topLabel = new Label("CS400 My First JavaFX Program");

    ComboBox<String> leftChoiceBox = new ComboBox<>(
        FXCollections.observableArrayList("A", "B", "C"));

    FileInputStream input = new FileInputStream("src/application/image.png");
    Image image = new Image(input, 600, 400, true, true);
    ImageView centerImageView = new ImageView(image);

    Button bottomButton = new Button("Done");


    VBox leftVBox = new VBox();
    TextField textField = new TextField();
    textField.setPromptText("Enter your name here");
    Button button = new Button("ok");
    Label label = new Label();
    bottomButton.setOnAction((ActionEvent e) -> {
      primaryStage.close();
    });
    button.setOnAction((ActionEvent e) -> {
      if (
          (textField.getText() != null && !textField.getText().isEmpty())
      ) {
        label.setText("Hi " + textField.getText());
      }
    });
    leftVBox.getChildren().addAll(textField,button, label);

    BorderPane bp = new BorderPane();
    bp.setTop(topLabel);
    bp.setLeft(leftChoiceBox);
    bp.setCenter(centerImageView);
    bp.setBottom(bottomButton);
    bp.setRight(leftVBox);
    primaryStage.setTitle("CS400 My First JavaFX Program");
    primaryStage.setScene(new Scene(bp, 600, 500));
    primaryStage.setResizable(false);
    primaryStage.show();
  }


  public static void main(String[] args) {
    launch(args);
  }
}
